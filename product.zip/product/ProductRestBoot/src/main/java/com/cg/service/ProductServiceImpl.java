package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Repository
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo productRepo;
	
	@Override
	public Product saveProduct(Product p) {
		return productRepo.save(p);
	}

	@Override
	public Product get(int id) {
		return productRepo.findById(id).get();
	}

	@Override
	public Product updateProduct(Product p) {
		return productRepo.save(p);
	}

	@Override
	public String deleteProduct(int id) {
		Product p = productRepo.findById(id).get();
		productRepo.delete(p);
		return "Deleted Successfully";
	}

	@Override
	public String getAll() {
		productRepo.deleteAll();
		return "Deleted All Records!!";
	}
	

}
