package com.cg.service;

import com.cg.entity.Product;

public interface ProductService {

	Product saveProduct(Product p);
	Product get(int id);
	Product updateProduct(Product p);
	String deleteProduct(int id);
	String getAll();

}
