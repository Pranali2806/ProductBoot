package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ProductService;

@RestController
public class HelloController {
	
	@Autowired
	ProductService productService;
	
	@PostMapping(name="/add",consumes="application/json",produces="application/json")
	public Product addProduct(@RequestBody Product p) {
		return productService.saveProduct(p);
	}
	
	@GetMapping(name="/find", produces="application/json")
	public Product getProduct(@RequestParam("id") int id) {
		Product p = productService.get(id);
		return p;
	}
	
	@PutMapping(name="/update")
	public Product updateProduct(@RequestParam("id") int id, @RequestParam("name") String productName, @RequestParam("price") int productPrice) {
		Product p = new Product();
		p.setId(id);
		p.setName(productName);
		p.setPrice(productPrice);
		return productService.updateProduct(p);
	}
	
	@DeleteMapping(name="/delete", produces="application/json")
	public String deleteProduct(@RequestParam("id") int id) {
		return productService.deleteProduct(id);
	}

	@GetMapping(name="/getAll", produces="application/json")
	public String getAllProduct() {
		return productService.getAll();
	}
}
